/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan9_145;

/**
 *
 * @author LABKOM
 */
public class penqueue {
        int[] arrayqueue;
        int kapasitas;
        int front;
        int rear;
        int arrayterpakai;
    public penqueue(int kapasitasAntrian){
        this.arrayqueue = new int[kapasitasAntrian];
        this.kapasitas = kapasitasAntrian;
        front = 0;
        rear = -1;
        arrayterpakai = 0;

        }
     public void enqueue(int item){
        arrayqueue[rear] = item; 
        arrayterpakai++;
        rear++;
    }
     public void dequeue(){
         front++;
         arrayterpakai--;
     }
     public void printantrian(){
         System.out.println("antrian saat ini = "+arrayqueue[front]);
     }
    public static void main(String[] args) {
            penqueue queue = new penqueue(4);
            
            queue.enqueue(10);
            queue.enqueue(20);
            queue.dequeue();
           queue.printantrian();
    }
}