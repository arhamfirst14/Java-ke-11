package pertemuan9_145;

public class Kalkulator implements Operasi {
    private double bil1, bil2; 
    
    Kalkulator(){}
    Kalkulator(double Bil1, double Bil2){
        this.bil1=Bil1;
        this.bil2=Bil2;
    }
    
    @Override
    public void Penjumlahan() {
        double hasil = this.bil1 + this.bil2;
        System.out.println("Hasil "+this.bil1+" ditambah "+this.bil2+" = "+hasil);
//        double hasil2 = this.bil1 + this.bil2;
//        System.out.println("Hasil "+this.bil1+" ditambah "+this.bil2+" = "+hasil2);
    }

    @Override
    public void Pengurangan() {
        double hasil = this.bil1-this.bil2;
        System.out.println("Hasil "+this.bil1+" dikurangi "+this.bil2+" = "+hasil);
//        double hasil2 = this.bil1-this.bil2;
//        System.out.println("Hasil "+this.bil1+" dikurangi "+this.bil2+" = "+hasil2);
    }

    @Override
    public void Perkalian() {
        double hasil = this.bil1*this.bil2;
        System.out.println("Hasil "+this.bil1+" dikali "+this.bil2+" = "+hasil);
    }

    @Override
    public void Pembagian() {
        double hasil = this.bil1/this.bil2;
        System.out.println("Hasil "+this.bil1+" dibagi "+this.bil2+" = "+hasil);
//        double hasi2 = this.bil1/this.bil2;
//        System.out.println("Hasil "+this.bil1+" dibagi "+this.bil2+" = "+hasil);
    }
    
}
