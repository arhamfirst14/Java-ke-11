package pertemuan9_145;

import java.util.Scanner;

public class penqueue {
        int[] arrayqueue;
        int kapasitas;
        int front;
        int rear;
        int arrayterpakai;
    public penqueue(int kapasitasAntrian){
        this.arrayqueue = new int[kapasitasAntrian];
        this.kapasitas = kapasitasAntrian;
        front = 0;
        rear = 0;
        arrayterpakai = 0;

        }
     public void enqueue(int item){
        arrayqueue[rear] = item; 
        arrayterpakai++;
        rear++;
    }
     public void dequeue(){
         front++;
         arrayterpakai--;
     }
     public void printantrian(){
         System.out.println("----tampilan antrian-----");
         System.out.println("antrian saat ini = "+arrayqueue[front]);
     }
    public static void main(String[] args) {
            penqueue queue = new penqueue(5);
            
            queue.enqueue(10);
            queue.enqueue(20);
            queue.enqueue(30);
            queue.enqueue(40);
            queue.enqueue(50);
//            queue.dequeue();
  //          queue.dequeue();
 //           queue.enqueue(60);
 //           queue.enqueue(70);
           queue.printantrian();
    }
}
