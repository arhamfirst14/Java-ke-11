package pertemuan9_145;

public interface Operasi {
    public void Penjumlahan();
    public void Pengurangan();
    public void Perkalian();
    public void Pembagian();
}
