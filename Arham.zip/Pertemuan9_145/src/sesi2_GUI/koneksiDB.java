
package sesi2_GUI;

import pertemuan9_145.*;
import java.sql.DriverManager;
import java.sql.SQLException;


public class koneksiDB {
    public static connection koneksi;
    
    public connection getKoneksi() throws SQLException{
   if (koneksi == null){
       try {
           String url = "jdbc:mysql://localhost:3306/mahasiswa";
           String username = "root";
           String password = "";
           
           DriverManager.registerDriver(new com.mysql.jdbc.Driver());
           koneksi = (connection) DriverManager.getConnection(url, username, password);
           System.out.println("koneksi berhasil");
       }catch(SQLException e) {
           System.out.println("koneksi gagal !!" +e.getMessage());
       }
   }
        return koneksi;
    }

    private static class connection {

        public connection() {
        }
    }
}
