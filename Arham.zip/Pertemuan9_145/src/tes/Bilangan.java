/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tes;

/**
 *
 * @author LABKOM
 */
public class Bilangan implements Operasi{
    double bil;
    
    Bilangan(){}
    Bilangan(double Bil){
        this.bil=Bil;
    }
    
    @Override
    public void Bilangan() {
        if (this.bil % 2 == 0) {
            System.out.print("Bilangan " + this.bil + " adalah Bilangan genap.\n");
        } else {
            System.out.print("Bilangan " + this.bil + " adalah Bilangan ganjil.\n");
        }
    }

    @Override
    public void Prima() {
        
    }

    @Override
    public void Pangkat() {
        
    }

    @Override
    public void Akar() {
        double bil2 = Math.sqrt(this.bil);
        System.out.println("kuadrat "+bil2);
    }
    
}
