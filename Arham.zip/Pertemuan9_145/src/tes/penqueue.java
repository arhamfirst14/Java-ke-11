package tes;

public class penqueue {
        int[] arrayqueue;
        int kapasitas,front,rear;
        int arrayterpakai;
    public penqueue(int kapasitasAntrian){
        this.arrayqueue = new int[kapasitasAntrian];
        this.kapasitas = kapasitasAntrian;
        front = 0;
        rear = -1;
        arrayterpakai = 0;

        }
     public void enqueue(int item){
        arrayqueue[rear] = item; 
        arrayterpakai++;
        rear++;
    }
     public void dequeue(){
         front++;
         arrayterpakai--;
     }
     public void printantrian(){
         System.out.println("antrian saat ini = "+arrayqueue[front]);
     }
    public static void main(String[] args) {
       
            penqueue queue = new penqueue(4);
            
            queue.enqueue(10);
            queue.enqueue(20);
            queue.dequeue();
            queue.printantrian();
    }
}
